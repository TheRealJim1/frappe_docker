---
created: ["{{date}} {{time}}"]
aliases: ["Book: {{title}}"]
tags:
- BookType/
---

# 📔 Book -> 
___
# ❓ Information
Type:: 
Writer:: 
Tags:: 
Subject:: 
Started Reading on:: 
Completed on:: 
Perched on:: 
Price:: 
___
# 🌍 What It's About
-  
# 🔍 How I Discovered IT
- 
# 🧠 Thoughts
- 
## What I Liked About IT
- 
## What I Didn't Like About it
- 
# ✍️ The Book in 3 Sentences
# ✍️ My Top 3 Quotes
# 🎨 Impressions
# ☘️ How the Book Changed Me
# 📒 Summary + Notes
# 🥰 Who Would Like it ?
- 
# 📚Related Books
- 
