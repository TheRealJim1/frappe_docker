---
created: ["{{date}} {{time}}"]
tags:
- AP/
---

# ❗ Information
Related to:: 
Tags:: 

# 🌌 Action plan -> 
---

# 🧾 Description
- 

## 🌐 Action to perform 
1. 