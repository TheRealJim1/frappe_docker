---
created: ["{{date: DD-MM-YYYY}} {{time}}"]
aliases: ["Project Code"]
tags:
- Project/
---

# 🚀 Project -> 
___

## 🧾 Project Description
- 
---
## 📢 Project information
Created:: {{date: DD-MM-YYYY}} {{time}}
Deadline:: 
Hibernating:: 
Completion date expected:: 
Completed:: 
Type:: 
Tags:: 
Platform:: 

___
## 🎯 Objective

1. 🟢 Ideal project result
	1. 
2. 🟠 Acceptable result
	1. 
## ❓ Expectations
1. 🟢 Helpful to the project
	1. 
2. 🟠 Roadblocks
	1. 
3. 👶 Naivety
	1. 
4. 👨‍💻 Insights
	1. 
## ✅ Tasks 
- 
## 📦 Resources 
- 
## 📂 Project Logs 
- 
