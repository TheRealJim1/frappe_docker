---
created: ["{{date}} {{time}}"]
aliases: ["Games: {{title}}"]
tags:
- Game/
---
## 🎮 Game Review ->
# ❓ Information
Type::.
Subject::. 
Started on::.
Completed on::.
Perched on::.
Price::.
Tags::.

1. Player Bases
	1. [ ] Kids
	2. [ ] Everyone
	3. [ ] Mature
	4. [ ] Causal Players
	5. [ ] Pro Players
2. Graphics
	1. [ ] Potato
	2. [ ] Made in 1960
	3. [ ] Bad
	4. [ ] OK
	5. [ ] Good
	6. [ ] Beautiful
	7. [ ] Masterpiece
3. Price recommendation
	1. [ ] Free
	2. [ ] Don't buy it 
	3. [ ] Refund it if you can
	4. [ ] Wait for sale
	5. [ ] Full price
4. Requirements
	1. [ ] Minimum
	2. [ ] Medium
	3. [ ] High end
	4. [ ] Super machine
5. Difficulty
	1. [ ] Easy
	2. [ ] Medium
	3. [ ] Hard
	4. [ ] Very hard
	5. [ ] Dark Souls
	6. [ ] Dark Souls Blind folded
6. Game Length
	1. [ ] Really short ( 0 -2 Hours)
	2. [ ] Short ( 2 - 8 Hours)
	3. [ ] Medium ( 8 - 16 Hours)
	4. [ ] Long ( 16+ Hours)
	5. [ ] Endless
7. Story
	1. [ ] It doesn't have one
	2. [ ] 5 year old can make it better
	3. [ ] Horrible
	4. [ ] OK
	5. [ ] Average
	6. [ ] Good
	7. [ ] Like watching a movie
8. Music or sound
	1. [ ] My ears are bleeding
	2. [ ] Horrible
	3. [ ] Decent
	4. [ ] Average
	5. [ ] Good
	6. [ ] Amazing
9. Gameplay
	1. [ ] Terrible
	2. [ ] OK
	3. [ ] Average
	4. [ ] Good
	5. [ ] Fantastic
10. Bugs
	1. [ ] The game is a bug
	2. [ ] Game braking bugs
	3. [ ] Lots of bugs
	4. [ ] Few bugs
	5. [ ] Nothing
11. Smurf's or Cheaters
	1. [ ] Like CS:GO
	2. [ ] Horrible
	3. [ ] Decent
	4. [ ] Average
	5. [ ] Good
	6. [ ] Amazing
12. Play style
	1. [ ] Single player
	2. [ ] Multi player
13. Final score
	1. 0/10