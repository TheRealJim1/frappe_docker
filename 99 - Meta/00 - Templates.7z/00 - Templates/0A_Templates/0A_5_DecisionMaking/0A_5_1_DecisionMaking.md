---
created: ["{{date}} {{time}}"]
tags:
- Evaluation/
---
# ❓ Your Questions is
- Brief description of the query.

## ✅ Reasoning for
1. 
## ⛔ Reasoning against
1. 
## 🔀 Alternatives considered
1. 
## 📦 Resources
- Link to any relevant information


## 🧮 Pros and Cons calculation

Pro | value 0-10 | Con | value 0-10
:--:|:-----|:------:|:------:|
Pro1| 10| Con 1 |10|
Pro1| 10| Con 1 |10|
Pro1| 10| Con 1 |10|
Pro1| 10| Con 1 |10|
Pro1| 10| Con 1 |10|
Pro1| 10| Con 1 |10|
Pro1| 10| Con 1 |10|
Pro1| 10| Con 1 |10|
Pro1| 10| Con 1 |10|
Pro1| 10| Con 1 |10|
Total Pro| 10| Total Con |10|

❗❗❗ If the total divided by 100 don't have at least 20% of difference add more Pros and Cons.