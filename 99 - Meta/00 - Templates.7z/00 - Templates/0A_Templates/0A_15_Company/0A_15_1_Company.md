---
aliases: ["Topic: {{title}}"]
created: ["{{date}} {{time}}"]
tags:
- Company/
---
# 🏦 Company -> 

---
## 📢 - Project information
Created::. {{date: DD-MM-YYYY}} {{time}}
Type::
Tags::
# 📅 - Schedule  
1. 