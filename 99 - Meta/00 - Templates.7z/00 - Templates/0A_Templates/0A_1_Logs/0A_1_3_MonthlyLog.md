---
created: ["{{date}} {{time}}"]
tags:
- Log/MonthlyLog
---

# 📆 Month {{date: MM/YYYY}}

## 🔃 Reflection
- 
### 🔷 Daily tasks completion rate

### 💯 Rating 0 -10
Happiness::
Productivity::
Relationships::
Focus::
### 📜 Events
**Biggest Personal Milestone**
- 
**Biggest Career Milestone**
- 
### 🚀 Projects
- 
### 🏢 Career
- 
### 📅 Future Plan
- 
### ✅ Action
> ***Be thorough in planning!***
- [ ] Update Tasks lists

### 📚 To Read



### 💾 Information to retain from the daily logs