---
created: ["{{date}} {{time}}"]
tags: 
- Log/WeeklyLog
---
___
```toc
 style: number
```
# 🌌 Overview -> 
```dataview
TABLE WITHOUT ID
	link(file.name) as "Day",
	Breakfast AS "🍜",
	Feeling AS "✨",
	working-on AS "✏️",
	money-spent AS "💸",
	Workout AS "💪",
	Motivation AS "💹"
WHERE file.folder = this.file.folder AND
 contains(tag, "#Log/dailylog") 
SORT file.name ASC
```

### 📑 Weekly Reviews
- 

### 🔃 Reflection
- 
### 📜 Events
- 
### 📃 Projects
#### **What did I accomplish?**
- 
#### **Am I satisfied with my progress?**
- 
#### **What setbacks did I face?**
- 
#### **What are some possible improvements and plans for the future??**
- 
### 💾 Information to retain from the daily logs
- 