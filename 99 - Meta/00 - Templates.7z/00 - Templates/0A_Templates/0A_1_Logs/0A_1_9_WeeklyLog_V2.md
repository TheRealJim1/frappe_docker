---
created: ["{{date}} {{time}}"]
tags:
- Log/WeeklLog
---
___
```toc
 style: number
```
# 🌌 Overview -> Week Report -> Week {{date:ww}}
🍜 - Breakfast |✨ - Feeling |✏️ - Working On 
💲 - Money Spent |💪 -Workout |📈 Motivation

| Day | 🍜  | ✨  | ✏️  | 💲  | 💪  | 📈  |
| --- | --- | --- | --- | --- | --- | --- |
|     |     |     |     |     |     |     |
### 📑 Got Done This Week
- 

### 🔃 Need to Work On
- 
### 📜 Events
- 
### 📃 Projects
- 
### 💾 Information to retain
- 
