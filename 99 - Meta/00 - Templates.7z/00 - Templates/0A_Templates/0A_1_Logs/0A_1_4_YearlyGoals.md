---
created: ["{{date}} {{time}}"]
tags:
- Log/YearlyGoals
---

### 🚀 Dream -

  

- 🧠 Why?

- 🎯 SMART Goal

- ⚛️ Habit?

- 🤯 How surprised would I be if I failed? (Scale of 1-10)

- ☠️ Top 3 Reasons for Failing

- 🦸 WHO can help?

- 📚 HOW can I stack the deck to succeed?

- 🔥 ACTION

  

# All below is just an example

### 🚀 Dream - Take better notes

  

- 🧠 Why?
	- Have all the information i need when i need it

- 🎯 SMART Goal
	- Use better and more easier to understand notes

- ⚛️ Habit?
	- Right a note every day enplaning to myself how was the day

- 🤯 How surprised would I be if I failed? (Scale of 1-10)
	- 10

- ☠️ Top 3 Reasons for Failing
	- Lack of time
	- Unable to use PC, Phone or Tablet for some reason
	- To much work going on that only leaves time to sleep

- 🦸 WHO can help?
	- Me, my self and I

- 📚 HOW can I stack the deck to succeed?
	- Instead of trying to make all the notes at once, make it as the day goes by 

- 🔥 ACTION
	- Set a timer for every task and stick to it 