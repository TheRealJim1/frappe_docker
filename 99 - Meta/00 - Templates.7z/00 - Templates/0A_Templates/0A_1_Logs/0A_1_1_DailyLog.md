---
created: ["{{date}} {{time}}"]
tags:
- Log/DaiLyLog
---

# 📅 Daily Log {{date: DD-MM-YYYY}}

---
## 🔷 Daily Tasks
- [ ] Breakfast
- [ ] Study something
- [ ] Work on personal projects
- [ ] Workout
	- [ ] Push up's
	- [ ] Sit downs
	- [ ] Deeps
# 🕴 Business
## 🎯 Objectives
- 
## 🚀 Working On
- 
## 📕 Reminders
- 
## 📚 Reading
- 
##  💬 Lingering feelings, Observations and Thoughts 
1. Lingering Feelings
	1. 
2. Observations
	1. 
3. Thoughts
	1. 
## 🔃 Reflection
1. 
---

## 📅 Today's Notes
- 🕛9:00 
	- Wok up and 