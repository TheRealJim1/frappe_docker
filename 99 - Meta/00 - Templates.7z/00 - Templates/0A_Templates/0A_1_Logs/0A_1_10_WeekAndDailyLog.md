---
created: "{{date}} at {{time}}"
aliases: "📆 - {{date:yyyy}}-W{{date:ww}}"
Tags: "Log/Weekly"
0A12Version: 1.3
---
---
# 📅 - Week Log - `=this.file.aliases[0]`
---
## 🌌 - Overview

| 📆 - Day | 💸 - Money Spent | ⚒ - Productivity Level | 🈺 - Day Type | 
| -------- | ---------------- | ---------------------- | ------------- |

---
## 📆 - Daily Events

### 🔰 - Day 
1. Personal
2. Work
3. Work & Personal
#### 🎯 - Daily Counters

##### 🍜 - Meals
Breakfast:: 
Lunch::
Dinner::
##### 🌟 - Feeling levels
Motivation::
Stress::
Physical Energy::
Mental Energy::
### 🔰 - Day 
1. Personal
2. Work
3. Work & Personal
#### 🎯 - Daily Counters

##### 🍜 - Meals
Breakfast:: 
Lunch::
Dinner::
##### 🌟 - Feeling levels
Motivation::
Stress::
Physical Energy::
Mental Energy::
### 🔰 - Day 
1. Personal
2. Work
3. Work & Personal
#### 🎯 - Daily Counters

##### 🍜 - Meals
Breakfast:: 
Lunch::
Dinner::
##### 🌟 - Feeling levels
Motivation::
Stress::
Physical Energy::
Mental Energy::
### 🔰 - Day 
1. Personal
2. Work
3. Work & Personal
#### 🎯 - Daily Counters

##### 🍜 - Meals
Breakfast:: 
Lunch::
Dinner::
##### 🌟 - Feeling levels
Motivation::
Stress::
Physical Energy::
Mental Energy::
### 🔰 - Day 
1. Personal
2. Work
3. Work & Personal
#### 🎯 - Daily Counters

##### 🍜 - Meals
Breakfast:: 
Lunch::
Dinner::
##### 🌟 - Feeling levels
Motivation::
Stress::
Physical Energy::
Mental Energy::
### 🔰 - Day 
1. Personal
2. Work
3. Work & Personal
#### 🎯 - Daily Counters

##### 🍜 - Meals
Breakfast:: 
Lunch::
Dinner::
##### 🌟 - Feeling levels
Motivation::
Stress::
Physical Energy::
Mental Energy::
### 🔰 - Day 
1. Personal
2. Work
3. Work & Personal
#### 🎯 - Daily Counters

##### 🍜 - Meals
Breakfast:: 
Lunch::
Dinner::
##### 🌟 - Feeling levels
Motivation::
Stress::
Physical Energy::
Mental Energy::

## 🔃 - Weekly Reflection

### 📜 - Events
**Personal Milestone**
- 
**Career Milestone**
- 
### 🧾 - Projects
**Projects started**
- 
**Projects completed**
- 
### ⌛ - Timeline
**What did I accomplish?**
- 
**Am I satisfied with my progress?**
- 
**What setbacks did I face?**
- 