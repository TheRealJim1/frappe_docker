---
created: ["{{date}} {{time}}"]
tags:
- Log/WeeklyReview
---
___

### 📅 Days
- 

### 📑 Weekly Reviews
- 

### 🔃 Reflection
- 
### 💯 Rating 0 - 10
- 
### 📜 Events
**Biggest Career Milestone**
- 
### 📃 Projects
**What did I accomplish?**
- 
**Am I satisfied with my progress?**
- 
**What setbacks did I face?**
- 
**What are some possible improvements and plans for the future??**

### 💾 Information to retain from the daily logs