---
created: ["{{date}} {{time}}"]
tags: 
- Log/YearlyReview
---

# 📆 YEAR {{date: YYYY}}
## 🔃 Reflection
- 
### 💯 Rating 0 -10
Happiness::
Productivity::
Relationships::
Focus::
### 📜 Events
**Biggest Personal Milestone**:: 
- 
**Biggest Career Milestone**:: 
- 
### 🚀 Projects
- 
### 🏢 Career
- 
### 📅 Future Plan
- 
### ✅ Action
> ***Be thorough in planning!***
- [ ] Update Yearly Objectives
- [ ] Update Task List
### 📚 To Read
- 
### 📗 Already read
- 
# ❓ Yearly Quiz
### 🔙 Past Year
1. Do you have a word for the year?
	1. 
2. What was the biggest Personal Milestone?
	1. 
3. What did you discover about yourself?
	1. 
4. When did fear hold you back?
	1. 
5. Where did you practice courage?
	1. 
6. What surprised you?
	1. 
7. How have you taken care of yourself physically?
	1. 
8. How have you taken care of yourself mentally?
	1. 
9. How have you taken care of yourself emotionally?
	1. 
10. What are you ready to begin?
	1. 
11. What are you ready to end?
	1. 
12. How has this year impacted your priorities?
	1. 
13. How has this year impacted your home life?
	1. 
14. How has this year impacted your relationships?
	1. 
15. How has this year impacted your work life?
	1. 

### ⏭ Next Year
1. What are you looking forward to in the next year?
	1. 
2. What are you feeling apprehensive about?
	1. 
3. What area of your life do you most want to develop in the next year?
	1. 
4. Where do you want to be in your head?
	1. 
5. Where do you want to be in your heart?
	1. 
6. What are your priorities for the next year?
	1. 
7. I will make more time for:
	1. 
8. I will learn about:
	1. 
9. I will say NO to:
	1. 
10. I will say YES to:
	1. 