---
created: ["{{date}} {{time}}"]
tags: 
- Log/DaiLyLog
---
# Metadata:
- Tag:: #Log/dailylog
- Created:: {{date: DD-MM-YYYY}}
- Week:: 

---

The function below requires the plugin Dynamic Table of Contents

```toc
 style: number
```

## 🔷Tracker
- Breakfast:: 
- Feeling:: 
- Working On:: 
- Money Spent:: 
- Workout:: 
- Motivation:: 

##  💬 Lingering feelings, Observations and Thoughts 
1. Lingering Feelings
	1. 
2. Observations
	1. 
3. Thoughts
	1. 
## 🔃 Reflection
1. 
---

## 📅 Today's Notes
- 🕛9:00 
	- Wok up and 