---
aliases: ["Topic: {{title}}", "Project:"]
created: ["{{date}} {{time}}"]
tags:
- Meeting/
---

# 🚀 Meeting -> 

---
## 📢 - Project information
Created::. {{date: DD-MM-YYYY}} {{time}}
Deadline:: 
Hibernating::. 
Completion date expected:: 
Completed:: 
Type:: 
Tags:: 
Platform:: 
Meeting Members :: 
# 📅 - Agenda
1. 
# 🎯 - Goals
1. 
# 📝 - Discussion notes
- 

# 💠 - Action items
- [ ] Meeting Notes Distributed to the Team
- [ ] Tasks & Projects Completed, Processed or Delegated
- [ ] Key Dates Completed or Scheduled
