---
aliases: ["Topic: {{title}}", "Project:"]
created: ["{{date}} {{time}}"]
tags:
- Meeting/Checkin/
---

# 👨‍💼 -> {{title}}

## 💹 -> Current progress
Take a moment to explain and show what you've achieved since the last check-in.

A quick demo video or sharing your screen.

## 🎯 -> Today's focus
Share what you expect to complete.

## ❌ -> What is getting in your way?
Use this section to inform your team of your challenges and get help on specific issues.