---
created: ["{{date}} {{time}}"]
aliases: ["{{title}}"]
tags:
- CourseNote/
---

# ❗❓ Information
Related to:: 
Tags:: 

# 🌌 Course -> 
---

# ❗ Description

 
## ❗ Answer