---
created: ["{{date}} {{time}}"]
aliases: ["{{title}}"]
tags:
- CourseNote/
---

# ❗❓ Information
Related to Course::
Date::
Professor/Speaker::
Tags::

---
# ❗ Topic

 
## 📦 Resources
- 
## 🔑 Key Points
- 
## ❓ Questions
- 
## 🎯 Actions
- [ ] 
- [ ] 
- [ ] 
- [ ] 
- [ ] 
## 📃 Summary of Notes
- 