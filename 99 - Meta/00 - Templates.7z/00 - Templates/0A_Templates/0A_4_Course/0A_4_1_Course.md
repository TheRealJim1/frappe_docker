---
created: ["{{date}} {{time}}"]
aliases: ["Course Code:"]
tags:
- Course/
---

# 📃 Course -> 

---
# ❓ Information
Type:: 
Speaker:: 
Course-Origin:: 
Subject:: 
Tags:: 
Started Reading on:: 
Completed on:: 
Perched on:: 
Price:: 
Certification:: 

# 🌍 What It's About
-   
---

## 📜 Notes and Ideas

## 🎯 Assignments
- 
## ⌛ Lectures
- 
## 📦 Resources
- 
## 📅 Important Dates
- 
