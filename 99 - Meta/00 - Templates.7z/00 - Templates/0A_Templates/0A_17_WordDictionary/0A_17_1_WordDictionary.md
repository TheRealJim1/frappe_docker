---
created: ["{{date: DD-MM-YYYY}} {{time}}"]
aliases: ["Dictionary: "]
tags:
- Dictionary/
---

# 📗 -> Insert word or here

## ❗ Information
Related to:: 

## 📄 -> Description 
- Simple or full description 

## 🗣 -> Context
- Context explanation

## 🧪-> Example
- Define examples where it can be used

## 🔗 -> Related Word
- Link all related words