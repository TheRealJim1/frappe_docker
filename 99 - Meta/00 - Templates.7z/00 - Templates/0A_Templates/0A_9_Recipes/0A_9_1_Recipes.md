---
created: ["{{date}} {{time}}"]
aliases: ["Recipe: {{title}}"]
tags:
- Recipe/
---

# 🍽 Recipe -> 

# ❓ Information
Type:: 
Origin:: 
Tags:: 
## 🍜 Ingredients
1. [ ] 

## 📑 Directions
1. [ ] 

