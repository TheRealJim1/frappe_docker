---
created: ["{{date}} {{time}}"]
aliases: ["Stock: {{title}}"]
tags:
- Investment/Stocks
---

# 🏦 -> Company

## 📢 Information
Company Name::
Symbol::
Price per Share::
Initial Value::
First Purchase Date::
Current amount of Shares::

## 💹 -> Price Control
🔰 - Account
📆 - Current Date
💲 - Price per Share
🔔 - Price at open bell
🔕 - Price at close bell
💱 - Price Percentage
| 📆 Day | 💲PPS | 🔔 Open Bell | 🔕Close Bell | 💱 % |
| ------ | ----- | ------------ | ------------ | ---- |
|        |       |              |              |      |

## 🔄 -> Shares Tracking

| 🔰 Acc | 📆 Day | 💲PPS | 💹 Share Purchased | 📉 Shares Sold |
| ------ | ------ | ----- | ------------------ | -------------- |
|        |        |       |                    |                |