---
created: ["{{date}} {{time}}"]
tags:
- List/
---
# 💠 Task List
## 🔴 URGENT
*Do it now*
- [ ] Task 1
- [ ] Task 2
- [ ] Task 3 
### 🟠 IMPORTANT 
*Do it after tasks above*
- [ ] Task 1
- [ ] Task 2
- [ ] Task 3 
#### 🟡 NOT URGENT / IMPORTANT
*Decide when to do it* 
- [ ] Task 1
- [ ] Task 2
- [ ] Task 3 
##### 🟢 Completed 
- [x] Task 1
- [x] Task 2
- [x] Task 3 