---
created: ["16-02-2022 17:38"]
aliases: ["{{title}}"]
tags:
- Entertainment/
- Movie/
---
# 🖼 -> Cover
Place a Show/Movie cover here
# 📺 -> Name
## 1️⃣ -> Introduction
Movie Name::
Author::
Release Date::
Purchased on::
Price::
Seasons/Movies:: 
Genre:: 
%% by default i use tag's to specify the genre, i have also checked some people making a file with a description for each genre but i believe that is better suited for a media vault %%

## 2️⃣ -> Summary
1. The story is about?
2. The setting is?
3. The theme is?

## 3️⃣ -> Analysis
Action::
Setting::
Language level::
Concepts::
Vocabulary:: 
## 4️⃣ -> Conclusion
1. You must watch / Not watch because?
2. If you liked this you may like ...
3. I give the Score

## 5️⃣ -> Global Information
Original name::
Started on::
Producer::
Studio::
Demographic::
Average Score::
