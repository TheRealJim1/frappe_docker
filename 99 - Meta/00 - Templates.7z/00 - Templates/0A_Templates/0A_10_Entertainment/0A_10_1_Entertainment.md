---
created: ["16-02-2022 17:38"]
aliases: ["{{title}}"]
tags:
- Entertainment/
---

# 📔 Type -> Name
___
|                               |     |     |
| ----------------------------- | --- | --- |
| Image::.                      |     |     |
| Original Name::.              |     |     |
| Started on::.                 |     |     |
| Completed on::.               |     |     |
| Perched on::.                 |     |     |
| Price::.                      |     |     |
| Producer::.                   |     |     |
| Studio::.                     |     |     |
| Writer::.                     |     |     |
| Genres::.                     |     |     |
| Demographic::.                |     |     |
| Rated::.                      |     |     |
| Score::.                      |     |     |
| Chapter/Episodes::.           |     |     |
| Chapter/Episodes completed::. |     |     |
| Tags::.                       |     |     |
___
## ❗ Impressions 
- 
### ❓ How I Discovered It ?
- 
