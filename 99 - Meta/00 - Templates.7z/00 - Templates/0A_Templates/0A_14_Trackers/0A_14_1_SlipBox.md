---
created: ["{{date}} {{time}}"]
tags:
- Frame/
---

# 📚 Slip Box 
## 1️⃣ - Life
## 2️⃣ - Happiness
## 3️⃣ - Meaning
## 4️⃣ - Work 
## 5️⃣ - Reading
## 6️⃣ - Luck
## 7️⃣ - Self-Improvement
## 8️⃣ - Relationships
## 9️⃣ - Helping People
## 1️⃣0️⃣ - Decision-Making
## 1️⃣1️⃣ - Money
## 1️⃣2️⃣ - Lifestyle
## 1️⃣3️⃣ - Writing
## 1️⃣4️⃣ - Social Skills
## 1️⃣5️⃣ - Productivity
## 1️⃣6️⃣ - Task Management
## 1️⃣7️⃣ - Studying & Learning
## 1️⃣8️⃣- Teaching


# Recommendation

If you are using dataview, I recommend using something  like this.
""
dataview
TABLE created AS "Date", status AS "Status" FROM #books AND !"0A_Templates"
""