---
created: ["{{date}} {{time}}"]
tags:
- Personal/
---


>Keeping track of a habit we what to get rid of or that we want to build helps us stay focused on the challenge. 
>This is a 30 day Track for a habit that we want gain or lose 


# 📅 My 30 Day's Challenge
## 📃 Challenge Information 
Created:: {{date: DD-MM-YYYY}} {{time}}
Starting On:: 
Completed:: 
Type:: 
Tags:: 

## 🎯 The habit I will gain/lose
- 

# ❗ Challenge Log


|       |     |     |     |     |     |     |     |
| ----- | --- | --- | --- | --- | --- | --- | --- |
| Day   | 1   | 2   | 3   | 4   | 5   | 6   | 7   |
| Notes |     |     |     |     |     |     |     |
| Day   | 8   | 9   | 10  | 11  | 12  | 13  | 14  |
| Notes |     |     |     |     |     |     |     |
| Day   | 15  | 16  | 17  | 18  | 19  | 20  | 21  |
| Notes |     |     |     |     |     |     |     |
| Day   | 22  | 23  | 24  | 25  | 26  | 27  | 28  |
| Notes |     |     |     |     |     |     |     |
| Day   | 29  | 30  |     |     |     |     |     |
| Notes |     |     |     |     |     |     |     |

### Congratulations! You made it to 30 days! You see if you can keep going.