---
created: "{{date}} at {{time}}"
aliases: "📆 - {{date}}"
Tags:
- "Log/Daily"
0A111Version: 2.0
---
---
# 📅 - Daily Log `=this.file.aliases[0]`
---
## 🎯 - Daily Counters

### 🍜 - Meals
Breakfast: 
Lunch: 
Dinner: 
### 🏋️‍♂️ - Exercise 
Push-Ups: 
Squads: 
Abs: 
### 🌟 - Feeling levels
Motivation: 
Stress: 
Physical Energy: 
Mental Energy: 
### 📚 - Reading
Manga: 
Book: 
### 💹 - Extra Measures
Weight: 
Calories: 
Steps: 
Sleep: 
